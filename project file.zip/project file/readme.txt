This is my first Andriod project.
this a versity based project.
this apps has a day and night mode.
United International University`s important all website include in this apps.
so that whats i called it all in one in home page.

thank you....