package com.example.madprojectfinal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

public class webfragment extends Fragment {

    ImageView web;
    ImageView ucam;
    ImageView lms;
    ImageView fbuiu;
    ImageView newboxuiu;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v= inflater.inflate(R.layout.fragment_webfragment, container, false);

        web = v.findViewById(R.id.webpic);
        ucam = v.findViewById(R.id.ucampic);
        lms = v.findViewById(R.id.lmspic);
        fbuiu = v.findViewById(R.id.fbuiupic);
        newboxuiu = v.findViewById(R.id.uiunbpic);

        web.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.uiu.ac.bd/");
            }
        });
        ucam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://ucam.uiu.ac.bd/Security/LogIn.aspx");
            }
        });
        lms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("http://lms.uiu.ac.bd/login/index.php");
            }
        });
        fbuiu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.facebook.com/uiuinfo");
            }
        });
        newboxuiu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.facebook.com/groups/138895140885708");
            }
        });

        return v;
    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }

}
